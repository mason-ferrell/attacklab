/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_272(unsigned *p)
{
    *p = 2462550344U;
}

void setval_192(unsigned *p)
{
    *p = 3281293400U;
}

unsigned addval_305(unsigned x)
{
    return x + 1481211249U;
}

void setval_378(unsigned *p)
{
    *p = 1491912884U;
}

void setval_214(unsigned *p)
{
    *p = 3347663020U;
}

unsigned addval_275(unsigned x)
{
    return x + 3251079496U;
}

unsigned addval_276(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_365(unsigned x)
{
    return x + 3281032280U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_169(unsigned x)
{
    return x + 2425405833U;
}

unsigned addval_317(unsigned x)
{
    return x + 3524837769U;
}

unsigned addval_132(unsigned x)
{
    return x + 3526940361U;
}

unsigned getval_273()
{
    return 3284830619U;
}

unsigned getval_189()
{
    return 3286272328U;
}

unsigned getval_207()
{
    return 3269495112U;
}

unsigned getval_149()
{
    return 3286272332U;
}

void setval_208(unsigned *p)
{
    *p = 3532966537U;
}

unsigned getval_286()
{
    return 3221280393U;
}

void setval_201(unsigned *p)
{
    *p = 3767093461U;
}

void setval_441(unsigned *p)
{
    *p = 3703821961U;
}

unsigned getval_316()
{
    return 3229925833U;
}

unsigned addval_311(unsigned x)
{
    return x + 3281308297U;
}

unsigned getval_303()
{
    return 3527985801U;
}

void setval_185(unsigned *p)
{
    *p = 3221804681U;
}

unsigned addval_204(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_113()
{
    return 3378566793U;
}

void setval_165(unsigned *p)
{
    *p = 3281046153U;
}

unsigned addval_482(unsigned x)
{
    return x + 3676357001U;
}

void setval_172(unsigned *p)
{
    *p = 3767027861U;
}

unsigned getval_472()
{
    return 2462747077U;
}

unsigned getval_467()
{
    return 2430634313U;
}

void setval_390(unsigned *p)
{
    *p = 3286270280U;
}

unsigned addval_197(unsigned x)
{
    return x + 3229139337U;
}

unsigned getval_357()
{
    return 2378285449U;
}

unsigned getval_190()
{
    return 3680551305U;
}

unsigned getval_401()
{
    return 2425476745U;
}

void setval_363(unsigned *p)
{
    *p = 3376993929U;
}

void setval_151(unsigned *p)
{
    *p = 2425542281U;
}

unsigned addval_106(unsigned x)
{
    return x + 3682126473U;
}

unsigned addval_198(unsigned x)
{
    return x + 3682910593U;
}

unsigned getval_147()
{
    return 2425408169U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
